const {contextBridge,ipcRenderer}=require('electron');
const methods=['list','create','get','statuses','timeline','status','settings','saveSettings','communications','saveCommunication','attachments','attach','pdf','print','clipboard','whatsapp','backup','entityList','entitySave','entityGet','delivery','deliveries','auditList','stats','exportCases','exportCSV','fullBackup','verifyBackup','health'];
contextBridge.exposeInMainWorld('rma',Object.fromEntries(methods.map(k=>[k,(...args)=>ipcRenderer.invoke(k,...args)])));
